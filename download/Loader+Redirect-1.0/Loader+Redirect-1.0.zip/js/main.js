// Created by Moonux Studio
let blinkCount = 3; // <-- Количество миганий логотипа
let currentCount = 0;

const blinkLogo = () => {
    const logo = document.getElementById("logo");
    logo.style.opacity = (currentCount % 2 === 0) ? "1" : "0";
    currentCount++;

    if (currentCount < blinkCount) {
        setTimeout(blinkLogo, 100);
    } else {
        window.location.href = "https://moonux.pro"; // <-- Здесь меняете на свою сыллку
    }
};

setTimeout(blinkLogo, 1000); // <-- Скорость мигания логотипа